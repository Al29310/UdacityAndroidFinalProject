package com.example.newsapp;

public class News {
    String articleTitle;
    String articleAuthor;
    String articleUrl;
    String date;
    int image;

    public News(String articleTitle, String date, String articleUrl){
        this.articleTitle = articleTitle;
        this.date = date;
        this.articleUrl = articleUrl;

    }


    public News(String articleTitle, String articleAuthor, String articleUrl, String data, int image) {
        this.articleTitle = articleTitle;
        this.articleAuthor = articleAuthor;
        this.articleUrl = articleUrl;
        this.date = date;
        this.image = image;

    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public String getArticleAuthor() {
        return articleAuthor;
    }

    public String getArticleUrl() {
        return articleUrl;
    }

    public int getImage() {
        return image;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public void setArticleAuthor(String articleAuthor) {
        this.articleAuthor = articleAuthor;
    }

    public void setArticleUrl(String articleUrl) {
        this.articleUrl = articleUrl;
    }

    public void setImage(int image) {
        this.image = image;
    }
}


