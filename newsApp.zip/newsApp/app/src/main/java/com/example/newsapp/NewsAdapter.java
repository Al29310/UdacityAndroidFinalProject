package com.example.newsapp;

public class NewsAdapter {
}
