package com.example.newsapp;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

public class Network extends AsyncTask<String, String, ArrayList<News>> {
    String url;

    public Network(String url) {
        this.url = url;
    }

    @Override
    protected ArrayList<News> doInBackground(String... strings) {
        ArrayList<News> guardianNews = new ArrayList<>();

        try {
            StringBuilder builder = new StringBuilder();
            URL url = new URL(this.url);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //connection.setRequestMethod("GET");

            InputStreamReader newsInput = new InputStreamReader(connection.getInputStream());
            BufferedReader reader = new BufferedReader((newsInput));


            String line = "";
            String data = "";

            while (reader.readLine() != null) {
                line = reader.readLine();
                Log.d("dataFromNetwork", data);
            }
            if (line != null && !(line.isEmpty()) ) {
                JSONObject jsonData = new JSONObject(data);
                JSONArray newsArticle = jsonData.getJSONArray("results");
                Log.d("JsonData1",newsArticle.toString());



                for (int i = 0; i < newsArticle.length(); i++) {


                    JSONObject currentObject = newsArticle.getJSONObject(i);
                    String currentArticleTitle = currentObject.getString("webTitle");
                    String currentArticleUrl = currentObject.getString("webUrl");
                    String currentArticleDate;

                    try {
                        if (!(currentObject.getString("webPublicationDate").isEmpty())) {
                            currentArticleDate = currentObject.getString("webPublicationDate");

                        } else {
                            currentArticleDate = "";
                        }
                        News news = new News(currentArticleTitle,currentArticleDate,currentArticleUrl);
                        guardianNews.add(news);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                    Log.d("jsonData2", newsArticle.toString());

                }

            }

        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return guardianNews;
    }

}
